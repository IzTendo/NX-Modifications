Made by IzTendo

To install the mod, place the 010024701dc2e000 folder in the correct directory for whatever platform you're using.

For Atmosphere on Switch - "SD Card Root\atmosphere\contents\"

For RYUJINX - "Ryujinx\sdcard\atmosphere\contents\"