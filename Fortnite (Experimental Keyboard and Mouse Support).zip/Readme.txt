Made by IzTendo

To install the mod, place the 010025400aece000 folder in the correct directory for whatever platform you're using.

For Atmosphere on Switch - "SD Card Root\atmosphere\contents\"

For RYUJINX (Not supported for Fortnite at the time of mod release) - "Ryujinx\sdcard\atmosphere\contents\"